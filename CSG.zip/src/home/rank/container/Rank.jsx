import React, { Component } from 'react';

import RankUi from '../ui/RankUi'
class Rank extends Component {
    render() {
        return (
            <>
             <RankUi></RankUi>   
            </>
        );
    }
}

export default Rank;