import React from 'react'

import RankPopUi from '../popui/RankPopUi'

const RankPop = (props) => {
   return (
      <RankPopUi {...props}></RankPopUi>
   )
}

export default RankPop