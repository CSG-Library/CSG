import React, { Component } from 'react'

const Art = (props) => {
   return (
      <div>
         文艺 渲染区域模块
      </div>
   )
}

export default Art