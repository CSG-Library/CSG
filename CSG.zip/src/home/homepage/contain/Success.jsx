import React, { Component } from 'react'

const Success = (props) => {
   return (
      <div>
         励志/成功 渲染区域模块
      </div>
   )
}

export default Success