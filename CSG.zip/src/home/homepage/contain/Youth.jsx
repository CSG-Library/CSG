import React, { Component } from 'react'

const Youth = (props) => {
   return (
      <div>
         青春 渲染区域模块
      </div>
   )
}

export default Youth