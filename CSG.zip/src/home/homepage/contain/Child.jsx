import React, { Component } from 'react'

const Child = (props) => {
   return (
      <div>
         少儿 渲染区域模块
      </div>
   )
}

export default Child