import React, { Component } from 'react'

const Life = (props) => {
   return (
      <div>
         生活 渲染区域模块
      </div>
   )
}

export default Life