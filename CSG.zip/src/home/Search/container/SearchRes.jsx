import React from 'react';
import SearchResUi from '../ui/SearchResUi';

const SearchRes = (props) => {
   return (
      <SearchResUi {...props} />
   )
}

export default SearchRes