import React, { Component } from 'react'
import PreciseSearchUi  from '../ui/PreciseSearchUi'
 class PreciseSearch extends Component {
    render() {
        return (
            <PreciseSearchUi />
        )
    }
}

export default PreciseSearch