import React from 'react';
// import PropsTypes from 'prop-types';

import UlWrap from '@c/booklist/UlWrap';

const ResComWrap = (props) => {
   return (
      <UlWrap currentPageList={props.currentPageList}></UlWrap>
   )
}

export default ResComWrap
