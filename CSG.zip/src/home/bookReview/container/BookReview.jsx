import React, { Component } from 'react'
import BookReviewUi from '../ui/BookReviewUi'
export class BookReview extends Component {
    render() {
        return (
            <BookReviewUi />
        )
    }
}

export default BookReview
