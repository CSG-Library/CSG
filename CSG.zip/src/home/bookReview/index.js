import Comment from './container/BookReview';

export {
   Comment
}