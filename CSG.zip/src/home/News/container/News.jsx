import React, { Component } from 'react';

import NewsUi from '../ui/NewsUi'

class MagazineNews extends Component {
  render() {
    return (
      <>
        <NewsUi></NewsUi>
      </>
    );
  }
}

export default MagazineNews;
