import React, { Component } from 'react'
import NewsContentUi from "../ui/NewsContentUi"

class NewsContent extends Component {
    render() {
        return (
            <NewsContentUi />
        )
    }
}

export default NewsContent
