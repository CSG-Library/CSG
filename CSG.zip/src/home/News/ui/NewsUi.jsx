import React from 'react';

import NewsCon from './NewsCon'

const MagazineUi = () => {
  return (
    <>
      <NewsCon></NewsCon>
    </>
  );
}

export default MagazineUi;
