import News from './container/News';
import NewsContent from './container/NewsContent';

export {
   News,
   NewsContent
}