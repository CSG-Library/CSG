const ONLIBRARY = '/onlineLibray/container/libraryNew'
export{
    ONLIBRARY
}