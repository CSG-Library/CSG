//当前文件夹的入口文件

import Introduce from './container/Introduce'
// import actionCreator from './actionCreator'
import reducer from  './reducer'

export {
    Introduce,
    reducer,
    // actionCreator 
}