import MagIntro from './container/MagIntro';

export {
   MagIntro
}