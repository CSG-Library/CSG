import React, { Component } from 'react';
import MagIntroUi from '../ui/MagIntroUi'

class MagIntro extends Component {
    render() {
        return (
            <>
               <MagIntroUi></MagIntroUi> 
            </>
        );
    }
}

export default MagIntro;