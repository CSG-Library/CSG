const CHANGESTATUS = 'home/shoppingCart/changeStatus'

const DELNUM = 'home/shoppingCart/delNum'

const ADDNUM = 'home/shoppingCart/addNum'

const DELETE = 'home/shoppingCart/delete'

const ALLCHANGE = 'home/shoppingCart/allChange'

const ADDSHOPPINGCART = 'home/shoppingCart/addShoppingCart'

export {
   CHANGESTATUS,
   DELNUM,
   ADDNUM,
   DELETE,
   ALLCHANGE,
   ADDSHOPPINGCART
}