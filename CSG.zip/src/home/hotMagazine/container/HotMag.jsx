import React from 'react'

import HotMagUi from '../ui/HotMagUi'

const HotMag = (props) => {
   return (
      <HotMagUi {...props}></HotMagUi>
   )
}

export default HotMag