import HotMag from './container/HotMag';
import HotMagdet from './container/Chapter';

export {
   HotMag,
   HotMagdet
}