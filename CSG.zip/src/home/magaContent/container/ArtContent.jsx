import React, { Component } from 'react';

import ArtContentUi from '../ui/ArtContentUi'

class ArtContent extends Component {
    render() {
        return (
            <>
               <ArtContentUi>
                   
                </ArtContentUi> 
            </>
        );
    }
}

export default ArtContent;