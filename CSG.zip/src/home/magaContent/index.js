import MagContent from './container/ArtContent';

export {
   MagContent
}