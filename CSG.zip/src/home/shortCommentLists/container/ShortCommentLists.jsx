import React, { Component } from 'react';

import ShortCommentListsUi from '../ui/ShortCommentListsUi'

class ShortCommentLists extends Component {
    render() {
        return (
            <>
                <ShortCommentListsUi></ShortCommentListsUi>
            </>
        );
    }
} 

export default ShortCommentLists;