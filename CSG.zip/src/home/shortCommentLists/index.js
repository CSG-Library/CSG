import ShortCommentList from './container/ShortCommentLists'
// import reducer from './reducer'
// import actionCraetor from './actionCreator'

export {
    ShortCommentList,
    // reducer,
    // actionCraetor
}