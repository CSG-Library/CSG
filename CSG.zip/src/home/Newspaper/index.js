import PaperNum from './container/NewspapersNum';
import Paperpage from './container/NewspaperReading';

export {
   PaperNum,
   Paperpage
}