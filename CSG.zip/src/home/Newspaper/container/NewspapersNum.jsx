import React, { Component } from 'react'
import NewspapersNumUi from '../ui/NewspapersNumUi'
export class NewspapersNum extends Component {
    render() {
        return (
            <NewspapersNumUi />
        )
    }
}

export default NewspapersNum
