import React,{Component} from 'react'
import NewspaperReadingUi from '../ui/NewspaperReadingUi'
export class NewspaperReading extends Component {
    render() {
        return (
            <NewspaperReadingUi />
        )
    }
}

export default NewspaperReading
