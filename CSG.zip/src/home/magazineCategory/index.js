import MagazineCategory from './container/MagazineCategory'
import reducer from './reducer'

export{
  MagazineCategory,
  reducer
}