const LOADDATA = 'home/introduce/loaddata'
const LOADDATA_ShortCom = 'home/introduce/loaddata/shortcom'
const  LOADDATA_LongCom = 'home/introduce/loaddata/longcom'

export {
    LOADDATA,
    LOADDATA_ShortCom,
    LOADDATA_LongCom
}