const SAVECOMP = 'my/BookRouter'
const LOADDATA='home/my/loaddata'
const ADDBOOKSHELF='home/my/addbookshelf'

export {
   SAVECOMP,
   LOADDATA,
   ADDBOOKSHELF
}

