import React, { Component } from 'react'

import Account from '../ui/Account'

export default class MyAccount extends Component {
  render() {
    return (
      <Account></Account>
    )
  }
}
