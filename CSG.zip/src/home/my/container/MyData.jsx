import React, { Component } from 'react'

import Data from '../ui/Data'

export default class MyAccount extends Component {
  render() {
    return (
      <Data></Data>
    )
  }
}

