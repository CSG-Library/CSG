import PaperCate from './container/PaperCate';
import reducer from './reducer';
import actionCreator from './actionCreator';

export {
   PaperCate,
   reducer,
   actionCreator
}

// 对外暴露 访问papercate的入口文件
