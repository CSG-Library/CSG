const LOADDATA = 'paperCate/load';
const CHANGECATESIDE = 'paperCate/change-cateside';

export {
   LOADDATA,
   CHANGECATESIDE 
}