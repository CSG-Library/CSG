const LOADLIST = './chapter/bookdet/list';
const SAVESTATU = './chapter/bookdet/statu';

export {
   LOADLIST,
   SAVESTATU
}