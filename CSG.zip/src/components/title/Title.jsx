import React from 'react';

import {
   TitleWraper
} from './StyleTitle'

const Title = () => {
   return (
      <TitleWraper>

      </TitleWraper>
   );
};

export default Title;